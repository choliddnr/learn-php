<?php

namespace App\Domain;

class Session
{
    public string $id;
    public int $user_id;

}
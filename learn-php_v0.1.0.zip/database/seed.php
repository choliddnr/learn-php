<?php
// $this->thetodos = [
// ['id' => 1, "title" => "Todo A", 'description' => "Description todo A", "deadline" => new DateTime()->getTimestamp(), 'status' => "ongoing"],
// ['id' => 2, "title" => "Todo B", 'description' => "Description todo B", "deadline" => new DateTime()->getTimestamp(), 'status' => "delayed"],
// ['id' => 3, "title" => "Todo C", 'description' => "Description todo C", "deadline" => new DateTime()->getTimestamp(), 'status' => "ongoing"],
// ['id' => 4, "title" => "Todo D", 'description' => "Description todo D", "deadline" => new DateTime()->getTimestamp(), 'status' => "done"],
// ['id' => 5, "title" => "Todo E", 'description' => "Description todo E", "deadline" => new DateTime()->getTimestamp(), 'status' => "delayed"],
// ['id' => 6, "title" => "Todo F", 'description' => "Description todo F", "deadline" => new DateTime()->getTimestamp(), 'status' => "ongoing"],
// ['id' => 7, "title" => "Todo G", 'description' => "Description todo G", "deadline" => new DateTime()->getTimestamp(), 'status' => "done"],
// ['id' => 8, "title" => "Todo H", 'description' => "Description todo H", "deadline" => new DateTime()->getTimestamp(), 'status' => "delayed"],
// ['id' => 9, "title" => "Todo I", 'description' => "Description todo I", "deadline" => new DateTime()->getTimestamp(), 'status' => "ongoing"],
// ['id' => 10, "title" => "Todo J", 'description' => "Description todo J", "deadline" => new DateTime()->getTimestamp(), 'status' => "delayed"],
// ['id' => 11, "title" => "Todo K", 'description' => "Description todo K", "deadline" => new DateTime()->getTimestamp(), 'status' => "done"],
// ['id' => 12, "title" => "Todo L", 'description' => "Description todo L", "deadline" => new DateTime()->getTimestamp(), 'status' => "ongoing"],
// ['id' => 13, "title" => "Todo M", 'description' => "Description todo M", "deadline" => new DateTime()->getTimestamp(), 'status' => "done"],
// ['id' => 14, "title" => "Todo N", 'description' => "Description todo N", "deadline" => new DateTime()->getTimestamp(), 'status' => "delayed"],
// ];
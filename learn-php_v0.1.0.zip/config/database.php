<?php
$dsn = 'sqlite';
$database_path = __DIR__ . "/../database/db.sqlite";
return ['dsn' => $dsn, 'path' => $database_path];
<?php
require_once __DIR__ . '/../vendor/autoload.php'; // Autoload dependencies
require_once __DIR__ . '/../app/router/routes.php'; // Load routes